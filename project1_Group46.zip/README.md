# Project 1

Jacob Everett, Devon Gates, Mitchell Koen, Ali Alsemeyen

Simple text document search engine that outputs information about the documents read in.

In order to compile this program on the UNT CSE machines, please type "g++ *.cpp" in the directory containing all the
.cpp/.h files for the project. Then type "./a.out" to run the program.

Once running, the program will prompt the user for a collection file and a stopwords file, then will output information. Once the data about the documents is output, the program will prompt the user to enter a query (space delimited list of words) and will output more data. 


